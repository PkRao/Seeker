import 'package:flutter/material.dart';

class SeekerScaffold extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? bottomNav;
  final FloatingActionButton? fab;

  const SeekerScaffold({
    super.key,
    this.appBar,
    required this.body,
    this.bottomNav,
    this.fab,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: appBar,
      floatingActionButton: fab,
      bottomNavigationBar: bottomNav,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0A0A0A),
              Color(0xFF1C1F26),
            ],
          ),
        ),
        child: Stack(
          children: [
            // glowing accents
            Positioned(
              top: -80,
              right: -50,
              child: _glowCircle(Colors.blueAccent.withOpacity(0.25)),
            ),
            Positioned(
              bottom: -30,
              left: -40,
              child: _glowCircle(Colors.white54,height:230,width:250),
            ),
            Positioned(
              bottom: -50,
              left: -30,
              child: _glowCircle(Colors.redAccent.withOpacity(0.2)),
            ), Positioned(
              bottom: -90,
              left: -40,
              child: _glowCircle(Colors.white38.withOpacity(0.2)),
            ),

            Positioned(
              bottom: -30,
              left: -20,
              child:  Image.asset(
                // 'assets/images/seeker_logo.png',
                'assets/images/dreamFly2.jpg',
                width: MediaQuery.of(context).size.width * 0.4,
              ),),

            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: body,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glowCircle(Color color,{double? width,double? height}) => Container(
    width:width?? 200,
    height:height?? 200,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: RadialGradient(
        colors: [color, Colors.transparent],
      ),
    ),
  );
}


class SeekerScaffoldBase extends StatefulWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? bottomNav;
  final FloatingActionButton? fab;
  final bool applyPadding;

  const SeekerScaffoldBase({
    super.key,
    this.appBar,
    required this.body,
    this.bottomNav,
    this.fab,
    this.applyPadding = true,
  });

  @override
  State<SeekerScaffoldBase> createState() => _SeekerScaffoldState();
}

class _SeekerScaffoldState extends State<SeekerScaffoldBase>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _color1;
  late Animation<Color?> _color2;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 6),
      vsync: this,
    )..repeat(reverse: true);

    _color1 = ColorTween(
      begin: const Color(0xFF0A0A0A),
      end: const Color(0xFF101820),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _color2 = ColorTween(
      begin: const Color(0xFF1A1A1A),
      end: const Color(0xFF111A25),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          extendBody: true,
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,
          appBar: widget.appBar,
          floatingActionButton: widget.fab,
          bottomNavigationBar: widget.bottomNav,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_color1.value!, _color2.value!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: widget.applyPadding
                    ? const EdgeInsets.symmetric(horizontal: 16, vertical: 10)
                    : EdgeInsets.zero,
                child: widget.body,
              ),
            ),
          ),
        );
      },
    );
  }
}
