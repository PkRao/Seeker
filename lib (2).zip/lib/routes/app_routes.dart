class AppRoutes {
  static const String splash = '/';
  static const String dashboard = '/dashboard';
  static const String home = '/dashboard';
  static const String deviceList = '/device-list';
  static const String settings = '/settings';
  static const String deviceDetail = '/device-detail';
  static const String provisioning = '/provisioning';
}
