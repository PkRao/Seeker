// lib/routes/route_generator.dart
import 'package:dfi_seekr/routes/app_routes.dart';
import 'package:dfi_seekr/view/screens/home/home_screen.dart';
import 'package:dfi_seekr/view/screens/splash/splash_screen.dart';
import 'package:flutter/material.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.splash:
        return MaterialPageRoute(builder: (_) => const SplashScreen());

      case AppRoutes.home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      // case AppRoutes.deviceList:
      //   return MaterialPageRoute(builder: (_) => const DeviceListScreen());

      // case AppRoutes.logs:
        // return MaterialPageRoute(builder: (_) => const LogsScreen());

      // case AppRoutes.settings:
      //   return MaterialPageRoute(builder: (_) => const SettingsScreen());

      default:
        return _errorRoute();
    }
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        body: Center(
          child: Text(
            '404 - Page Not Found',
            style: TextStyle(fontSize: 18, color: Colors.redAccent),
          ),
        ),
      ),
    );
  }
}
