// lib/routes/app_routes.dart

class AppRoutes {
  static const String splash = '/';
  static const String home = '/home';
  static const String deviceList = '/device-list';
  static const String logs = '/logs';
  static const String settings = '/settings';
}
