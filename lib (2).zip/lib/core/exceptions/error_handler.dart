import '../utils/logger.dart';

void handleError(Object e, StackTrace s) {
  // central place to send errors to logging or crash reporting
  logError('ErrorHandler', e.toString());
  // send to Sentry / Firebase Crashlytics here if needed
}
