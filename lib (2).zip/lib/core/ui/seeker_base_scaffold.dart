import 'package:flutter/material.dart';

class SeekerBaseScaffold extends StatefulWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? bottomNav;
  final FloatingActionButton? fab;
  final bool applyPadding;

  const SeekerBaseScaffold({
    super.key,
    this.appBar,
    required this.body,
    this.bottomNav,
    this.fab,
    this.applyPadding = true,
  });

  @override
  State<SeekerBaseScaffold> createState() => _SeekerBaseScaffoldState();
}

class _SeekerBaseScaffoldState extends State<SeekerBaseScaffold>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _color1;
  late Animation<Color?> _color2;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 6),
      vsync: this,
    )..repeat(reverse: true);

    _color1 = ColorTween(
      begin: const Color(0xFF0A0A0A),
      end: const Color(0xFF101820),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _color2 = ColorTween(
      begin: const Color(0xFF1A1A1A),
      end: const Color(0xFF111A25),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          extendBody: true,
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,
          appBar: widget.appBar,
          floatingActionButton: widget.fab,
          bottomNavigationBar: widget.bottomNav,
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_color1.value!, _color2.value!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: widget.applyPadding
                    ? const EdgeInsets.symmetric(horizontal: 16, vertical: 10)
                    : EdgeInsets.zero,
                child: widget.body,
              ),
            ),
          ),
        );
      },
    );
  }
}
