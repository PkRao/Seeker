void logInfo(String tag, String msg) {
  // placeholder logger - replace with more advanced logging if needed
  // e.g., use package:logger for structured logs
  // For now, print with tag for easy debugging.
  print('[INFO] [$tag] $msg');
}

void logError(String tag, String msg) {
  print('[ERROR] [$tag] $msg');
}
