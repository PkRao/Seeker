bool isValidPhone(String phone) {
  final p = RegExp(r'^\d{10}\$');
  return p.hasMatch(phone);
}
