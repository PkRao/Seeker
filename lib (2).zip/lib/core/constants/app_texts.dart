class AppTexts {
  static const String appName = 'Seeker';
  static const String splashTagline = 'Track. Monitor. Deliver.';
}
