class AppConfig {
  static const int scanTimeoutSeconds = 20;
  static const int reconnectAttempts = 5;
  static const int rssiFloor = -75;
}
