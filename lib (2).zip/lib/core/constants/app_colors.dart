import 'package:flutter/material.dart';

class AppColors {
  static const Color darkBg = Color(0xFF0A0A0A);
  static const Color darkGradientTop = Color(0xFF101820);
  static const Color darkGradientBottom = Color(0xFF1A2A3A);
  static const Color accentBlue = Color(0xFF00ADEF);
  static const Color accentRed = Color(0xFFE53935);
}
