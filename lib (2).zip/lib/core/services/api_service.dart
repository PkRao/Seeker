import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import '../utils/logger.dart';

class ApiService {
  final String baseUrl;

  ApiService({required this.baseUrl});

  Future<Map?> get(String path) async {
    final url = Uri.parse(baseUrl + path);
    try {
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        return jsonDecode(res.body) as Map;
      } else {
        logError('ApiService', 'GET ${url} -> ${res.statusCode}');
      }
    } catch (e) {
      logError('ApiService', 'GET error: \$e');
    }
    return null;
  }

  Future<Map?> post(String path, Map body) async {
    final url = Uri.parse(baseUrl + path);
    try {
      final res = await http.post(url, body: jsonEncode(body), headers: {'Content-Type':'application/json'});
      if (res.statusCode == 200 || res.statusCode == 201) {
        return jsonDecode(res.body) as Map;
      } else {
        logError('ApiService', 'POST ${url} -> ${res.statusCode}');
      }
    } catch (e) {
      logError('ApiService', 'POST error: \$e');
    }
    return null;
  }
}
