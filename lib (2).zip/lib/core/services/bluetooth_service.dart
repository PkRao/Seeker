import 'dart:async';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import '../constants/app_config.dart';
import '../utils/logger.dart';

class BluetoothService {
  final FlutterReactiveBle _ble = FlutterReactiveBle();
  final Map<String, DiscoveredDevice> _devices = {};
  StreamSubscription<DiscoveredDevice>? _scanSub;

  // expose devices as a stream using simple stream controller
  final _devicesController = StreamController<List<DiscoveredDevice>>.broadcast();
  Stream<List<DiscoveredDevice>> get devicesStream => _devicesController.stream;

  void startScan() {
    stopScan();
    logInfo('BluetoothService', 'Starting scan for ${AppConfig.scanTimeoutSeconds}s');
    _scanSub = _ble.scanForDevices(withServices: []).listen((device) {
      if (device.rssi != null && device.rssi! < AppConfig.rssiFloor) return;
      _devices[device.id] = device;
      _devicesController.add(_devices.values.toList());
    }, onError: (e) {
      logError('BluetoothService', 'Scan error: \$e');
    });
    // stop scanning after timeout
    Future.delayed(Duration(seconds: AppConfig.scanTimeoutSeconds), () => stopScan());
  }

  void stopScan() {
    _scanSub?.cancel();
    _scanSub = null;
  }

  Future<bool> connect(String deviceId) async {
    try {
      final conn = _ble.connectToDevice(id: deviceId, connectionTimeout: const Duration(seconds: 10));
      await conn.firstWhere((e) => e.connectionState == DeviceConnectionState.connected);
      logInfo('BluetoothService', 'Connected to \$deviceId');
      return true;
    } catch (e) {
      logError('BluetoothService', 'Connect error: \$e');
      return false;
    }
  }

  void dispose() {
    _devicesController.close();
    stopScan();
  }
}
