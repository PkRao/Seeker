import 'package:hive/hive.dart';

class HiveService {
  static const String boxName = 'seekrBox';

  Future<void> saveString(String key, String value) async {
    final box = Hive.box(boxName);
    await box.put(key, value);
  }

  String? getString(String key) {
    final box = Hive.box(boxName);
    return box.get(key) as String?;
  }

  Future<void> saveMap(String key, Map value) async {
    final box = Hive.box(boxName);
    await box.put(key, value);
  }

  Map? getMap(String key) {
    final box = Hive.box(boxName);
    return box.get(key) as Map?;
  }
}
