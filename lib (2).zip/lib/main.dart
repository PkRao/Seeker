import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'routes/app_routes.dart';
import 'routes/route_generator.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive local storage
  await Hive.initFlutter();
  // open default box (example)
  await Hive.openBox('appBox');

  // Request runtime permissions used by the app (Bluetooth & Location on Android)
  await _requestPermissions();

  runApp(const SeekerApp());
}

Future<void> _requestPermissions() async {
  // Request necessary permissions; platform specifics may vary.
  await Permission.location.request();
  await Permission.bluetooth.request();
  await Permission.bluetoothScan.request();
  await Permission.bluetoothConnect.request();
  // On Android 12+, you might need BLUETOOTH_SCAN and BLUETOOTH_CONNECT
}

class SeekerApp extends StatelessWidget {
  const SeekerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seeker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.transparent,
        appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0),
      ),
      initialRoute: AppRoutes.dashboard,
      onGenerateRoute: RouteGenerator.generateRoute,
    );
  }
}
