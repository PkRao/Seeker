import 'package:flutter/material.dart';
import '../../../core/ui/seeker_base_scaffold.dart';
import '../../../core/utils/logger.dart';

class ProvisioningPage extends StatefulWidget {
  const ProvisioningPage({super.key});

  @override
  State<ProvisioningPage> createState() => _ProvisioningPageState();
}

class _ProvisioningPageState extends State<ProvisioningPage> {
  String? scanned;

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map?;
    final deviceId = args != null ? args['deviceId'] as String? : null;

    return SeekerBaseScaffold(
      appBar: AppBar(title: const Text('Provision Tracker'), backgroundColor: Colors.transparent, elevation: 0),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 8),
          const Text('Scan Tracker QR to provision (MAC ID expected)', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          // Expanded(
          //   child: ClipRRect(
          //     borderRadius: BorderRadius.circular(12),
          //     child: MobileScanner(
          //       // allowDuplicates: false,
          //       onDetect: (barcode, args) {
          //         final String? code = barcode.rawValue;
          //         if (code == null) return;
          //         logInfo('Provisioning', 'Scanned: \$code');
          //         setState(() {
          //           scanned = code;
          //         });
          //         // return to previous screen with scanned value
          //         Navigator.pop(context, {'scanned': code, 'deviceId': deviceId});
          //       },
          //     ),
          //   ),
          // ),
          const SizedBox(height: 12),
          if (scanned != null)
            Text('Last scanned: \$scanned', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
