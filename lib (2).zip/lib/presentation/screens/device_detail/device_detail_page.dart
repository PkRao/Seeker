import 'package:flutter/material.dart';
import '../../../core/ui/seeker_base_scaffold.dart';
import '../../../presentation/widgets/battery_info_tile.dart';

class DeviceDetailPage extends StatelessWidget {
  final String deviceId;
  const DeviceDetailPage({super.key, required this.deviceId});

  @override
  Widget build(BuildContext context) {
    // Mock data for two batteries
    final battery1 = {
      'voltage': 12.6,
      'temperature': 32.4,
      'charge': 78,
      'batteryId': 'BATT-01',
      'trackerId': 'AA:BB:CC:DD:01'
    };
    final battery2 = {
      'voltage': 12.4,
      'temperature': 31.8,
      'charge': 74,
      'batteryId': 'BATT-02',
      'trackerId': 'AA:BB:CC:DD:02'
    };

    return SeekerBaseScaffold(
      appBar: AppBar(
        title: Text('Device $deviceId'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            Text('Battery 1', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white)),
            const SizedBox(height: 8),
            BatteryInfoTile(data: battery1),
            const SizedBox(height: 20),
            Text('Battery 2', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white)),
            const SizedBox(height: 8),
            BatteryInfoTile(data: battery2),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                // open provisioning screen for battery selection
                Navigator.pushNamed(context, '/provisioning', arguments: {'deviceId': deviceId});
              },
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Change Battery Info (Provision)'),
            ),
          ],
        ),
      ),
    );
  }
}
