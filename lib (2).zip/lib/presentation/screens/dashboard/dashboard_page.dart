import 'package:flutter/material.dart';
import '../../../core/ui/seeker_base_scaffold.dart';
import '../../../core/services/bluetooth_service.dart';
import '../../../core/utils/logger.dart';
import '../../widgets/device_card.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final BluetoothService _bluetooth = BluetoothService();
  List devices = [];

  @override
  void initState() {
    super.initState();
    _bluetooth.devicesStream.listen((list) {
      setState(() {
        devices = list;
      });
    });
    // start scanning on screen open
    _bluetooth.startScan();
  }

  @override
  void dispose() {
    _bluetooth.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SeekerBaseScaffold(
      appBar: AppBar(
        title: const Text('Seeker Dashboard'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Text(
            'Discovered Devices',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: devices.isEmpty
                ? const Center(child: Text('No devices found', style: TextStyle(color: Colors.white54)))
                : ListView.builder(
                    itemCount: devices.length,
                    itemBuilder: (context, index) {
                      final d = devices[index];
                      return DeviceCard(
                        id: d.id,
                        name: d.name ?? d.id,
                        rssi: d.rssi ?? 0,
                        onTap: () async {
                          // navigate to device detail and wait for provisioning result
                          final res = await Navigator.pushNamed(context, '/device-detail', arguments: {'deviceId': d.id});
                          if (res != null && res is Map && res.containsKey('provisioned')) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Provisioning updated')));
                          }
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
