import 'package:flutter/material.dart';

class DeviceCard extends StatelessWidget {
  final String id;
  final String name;
  final int rssi;
  final VoidCallback onTap;

  const DeviceCard({super.key, required this.id, required this.name, required this.rssi, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white10,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        title: Text(name.isEmpty ? id : name, style: const TextStyle(color: Colors.white)),
        subtitle: Text('RSSI: \$rssi', style: const TextStyle(color: Colors.white70)),
        trailing: IconButton(icon: const Icon(Icons.arrow_forward_ios, color: Colors.white70), onPressed: onTap),
      ),
    );
  }
}
