import 'package:flutter/material.dart';
import '../../core/utils/formatters.dart';

class BatteryInfoTile extends StatelessWidget {
  final Map data;
  const BatteryInfoTile({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white10,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Battery ID:  ${data['batteryId']}', style: const TextStyle(color: Colors.white)),
            const SizedBox(height: 6),
            Text('Tracker: ${data['trackerId']}', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Voltage', style: TextStyle(color: Colors.white54)),
                    Text(formatVoltage(data['voltage'] as double), style: const TextStyle(color: Colors.white)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Temp', style: TextStyle(color: Colors.white54)),
                    Text(formatTemperature(data['temperature'] as double), style: const TextStyle(color: Colors.white)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Charge', style: TextStyle(color: Colors.white54)),
                    Text('${data['charge']} %', style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
