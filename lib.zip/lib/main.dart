import 'package:dfi_seekr/core/services/hive_service.dart';
import 'package:flutter/material.dart';
import 'routes/app_routes.dart';
import 'routes/route_generator.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'presentation/screens/dashboard/dashboard_page.dart';
import 'routes/app_routes.dart';
import 'routes/route_generator.dart';

void main_one() {
  runApp(const SeekerApp());
}

class SeekerApp_old extends StatelessWidget {
  const SeekerApp_old({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seeker App',
      debugShowCheckedModeBanner: false,
      initialRoute: AppRoutes.splash,
      onGenerateRoute: RouteGenerator.generateRoute,
      theme: ThemeData.dark(),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive local storage
  await Hive.initFlutter();
  // open default box (example)
  await Hive.openBox('${HiveService.boxName}');

  // Request runtime permissions used by the app (Bluetooth & Location on Android)
  await _requestPermissions();

  runApp(const SeekerApp());
}


 _requestPermissions() async {
  if (await Permission.bluetooth.request().isGranted) {
  } else {
    await Permission.bluetooth.request();
    if (await Permission.bluetooth.request().isGranted) {
    } else {
      await Permission.bluetooth.request();
    }
  }
  if (!await Permission.locationWhenInUse.isGranted) {
    await Permission.locationWhenInUse.request();
  }

  if (!await Permission.location.isGranted) {
    await Permission.location.request();
  }
  if (!await Permission.bluetoothScan.status.isGranted) {
    await Permission.bluetoothScan.request();
  }
  if (!await Permission.mediaLibrary.isGranted) {
    await Permission.mediaLibrary.request();
  }

  if (!await Permission.camera.status.isGranted) {
    await Permission.camera.request();
  }
  // if (!await Permission.phone.status.isGranted) {
  //   await Permission.phone.request();
  // }
  if (!await Permission.bluetoothConnect.status.isGranted) {
    await Permission.bluetoothConnect.request();
  }
  if (!await Permission.location.status.isGranted) {
    await Permission.location.request();
  }
  if (!await Permission.locationWhenInUse.status.isGranted) {
    await Permission.locationWhenInUse.request();
  }
}

class SeekerApp extends StatelessWidget {
  const SeekerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seeker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.transparent,
        appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0),
      ),
      initialRoute: AppRoutes.splash,
      onGenerateRoute: RouteGenerator.generateRoute,
    );
  }
}
